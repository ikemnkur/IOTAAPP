Sound pack downloaded from Freesound
----------------------------------------

"Gurgorecordings"

This pack of sounds contains sounds by the following user:
 - vikuserro ( https://freesound.org/people/vikuserro/ )

You can find this pack online at: https://freesound.org/people/vikuserro/packs/15248/


Licenses in this pack (see below for individual sound licenses)
---------------------------------------------------------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/
Attribution 4.0: https://creativecommons.org/licenses/by/4.0/


Sounds in this pack
-------------------

  * 613987__vikuserro__mad-husband.wav
    * url: https://freesound.org/s/613987/
    * license: Creative Commons 0
  * 448381__vikuserro__being-sick.wav
    * url: https://freesound.org/s/448381/
    * license: Creative Commons 0
  * 448380__vikuserro__strong-man-lift.wav
    * url: https://freesound.org/s/448380/
    * license: Creative Commons 0
  * 341042__vikuserro__snore.wav
    * url: https://freesound.org/s/341042/
    * license: Attribution 4.0
  * 341041__vikuserro__dog-stimulation.wav
    * url: https://freesound.org/s/341041/
    * license: Attribution 4.0
  * 341040__vikuserro__mad-father.wav
    * url: https://freesound.org/s/341040/
    * license: Attribution 4.0
  * 341039__vikuserro__whiny-female.wav
    * url: https://freesound.org/s/341039/
    * license: Attribution 4.0
  * 341038__vikuserro__sneezing.wav
    * url: https://freesound.org/s/341038/
    * license: Attribution 4.0
  * 341037__vikuserro__snooty-teen.wav
    * url: https://freesound.org/s/341037/
    * license: Attribution 4.0
  * 341036__vikuserro__hehehe-laughter.wav
    * url: https://freesound.org/s/341036/
    * license: Attribution 4.0
  * 341035__vikuserro__hop-jump.wav
    * url: https://freesound.org/s/341035/
    * license: Attribution 4.0
  * 341034__vikuserro__mniam-mniam-hungry.wav
    * url: https://freesound.org/s/341034/
    * license: Attribution 4.0
  * 341033__vikuserro__oh-no.wav
    * url: https://freesound.org/s/341033/
    * license: Attribution 4.0
  * 341032__vikuserro__yeb-hitting.wav
    * url: https://freesound.org/s/341032/
    * license: Attribution 4.0
  * 341031__vikuserro__yahoo-jump.wav
    * url: https://freesound.org/s/341031/
    * license: Attribution 4.0
  * 341020__vikuserro__dragon-sound.wav
    * url: https://freesound.org/s/341020/
    * license: Attribution 4.0
  * 341019__vikuserro__go-away-bitch.wav
    * url: https://freesound.org/s/341019/
    * license: Attribution 4.0
  * 341018__vikuserro__barking-2.wav
    * url: https://freesound.org/s/341018/
    * license: Attribution 4.0
  * 341017__vikuserro__chainsaw-ii.wav
    * url: https://freesound.org/s/341017/
    * license: Attribution 4.0
  * 341016__vikuserro__cleaning-teeth.wav
    * url: https://freesound.org/s/341016/
    * license: Attribution 4.0
  * 341015__vikuserro__dog-hit.wav
    * url: https://freesound.org/s/341015/
    * license: Attribution 4.0
  * 341014__vikuserro__chainsaw.wav
    * url: https://freesound.org/s/341014/
    * license: Attribution 4.0
  * 341013__vikuserro__duck-dies.wav
    * url: https://freesound.org/s/341013/
    * license: Attribution 4.0
  * 341012__vikuserro__yawning-just-woke-up.wav
    * url: https://freesound.org/s/341012/
    * license: Attribution 4.0
  * 341011__vikuserro__ouch.wav
    * url: https://freesound.org/s/341011/
    * license: Attribution 4.0
  * 246310__vikuserro__meh-vocal.wav
    * url: https://freesound.org/s/246310/
    * license: Attribution 4.0
  * 246309__vikuserro__sadness.wav
    * url: https://freesound.org/s/246309/
    * license: Attribution 4.0
  * 246308__vikuserro__vomiting.wav
    * url: https://freesound.org/s/246308/
    * license: Attribution 4.0
  * 246307__vikuserro__yes-decisive.wav
    * url: https://freesound.org/s/246307/
    * license: Attribution 4.0
  * 246306__vikuserro__aroused.wav
    * url: https://freesound.org/s/246306/
    * license: Attribution 4.0
  * 246305__vikuserro__excited.wav
    * url: https://freesound.org/s/246305/
    * license: Attribution 4.0
  * 246304__vikuserro__ey-shouting.wav
    * url: https://freesound.org/s/246304/
    * license: Attribution 4.0
  * 246303__vikuserro__mad-dude.wav
    * url: https://freesound.org/s/246303/
    * license: Attribution 4.0


